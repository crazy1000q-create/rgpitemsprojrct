package com.example.rpgitems;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** Item that shows custom tooltip lines. */
public class LoreItem extends Item {
    private final List<Component> lines;

    public LoreItem(Item.Properties props, List<Component> lines) {
        super(props);
        this.lines = lines;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.addAll(lines);
    }
}
