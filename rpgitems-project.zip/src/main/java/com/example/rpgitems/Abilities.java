package com.example.rpgitems;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

import java.util.List;

public class Abilities {

    static List<LivingEntity> near(ServerLevel w, LivingEntity c, double r) {
        return w.getEntitiesOfClass(LivingEntity.class, c.getBoundingBox().inflate(r),
                e -> e != c && e.isAlive());
    }

    /** Skill damage (scaled by Reaper armor Skill Damage %). */
    static void hit(ServerLevel w, ServerPlayer p, LivingEntity e, float dmg) {
        float finalDmg = dmg * (float) ArmorStats.skillDamageMult(p);
        e.invulnerableTime = 0;
        e.hurtServer(w, w.damageSources().playerAttack(p), finalDmg);
    }

    /** Root = cannot move or jump. */
    static void root(LivingEntity e, int ticks) {
        e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, ticks, 254, false, false));
        e.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, ticks, 128, false, false));
    }

    static void immune(LivingEntity e, int ticks) {
        e.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, ticks, 4, false, false));
    }

    // Terrestrial: Leap of Faith (120s)
    public static void leapOfFaith(ServerLevel w, ServerPlayer p) {
        immune(p, 80);
        p.setDeltaMovement(0, 1.4, 0);
        p.hurtMarked = true;
        RpgItems.schedule(14, () -> { p.setDeltaMovement(0, -2.5, 0); p.hurtMarked = true; });
        RpgItems.schedule(26, () -> {
            w.sendParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY(), p.getZ(), 10, 2, 0.2, 2, 0.1);
            for (LivingEntity e : near(w, p, 5)) {
                hit(w, p, e, 1000);
                root(e, 60);
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60)); // "crumbled" marker
            }
        });
    }

    // Absolute Zero: Frozen Tomb (80s)
    public static void frozenTomb(ServerLevel w, ServerPlayer p) {
        immune(p, 60);
        root(p, 60);
        w.sendParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 80, 0.6, 1, 0.6, 0.05);
        RpgItems.schedule(60, () -> {
            w.sendParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 300, 4, 1, 4, 0.2);
            for (LivingEntity e : near(w, p, 6)) {
                hit(w, p, e, 250);
                root(e, 60); // stun 3s
            }
        });
    }

    // Blightspore: Bloodburst (5s)
    public static void bloodburst(ServerLevel w, ServerPlayer p) {
        float max = p.getMaxHealth();
        p.setHealth(Math.max(1f, p.getHealth() - max * 0.10f));
        w.sendParticles(ParticleTypes.DAMAGE_INDICATOR, p.getX(), p.getY() + 1, p.getZ(), 60, 2, 1, 2, 0.1);
        for (LivingEntity e : near(w, p, 6)) hit(w, p, e, max * 10f);
    }

    // The Cataclysm: Doomsday (85s)
    public static void doomsday(ServerLevel w, ServerPlayer p) {
        root(p, 60);
        w.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 150, 1, 1, 1, 0.5);
        RpgItems.schedule(60, () -> {
            w.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0, 0, 0);
            float dmg = 650f + p.getMaxHealth();
            for (LivingEntity e : near(w, p, 8)) hit(w, p, e, dmg);
        });
    }
}
