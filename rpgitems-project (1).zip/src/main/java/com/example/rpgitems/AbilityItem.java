package com.example.rpgitems;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;

/** Weapon with a right-click ability and cooldown (reduced by Reaper armor CDR). */
public class AbilityItem extends LoreItem {
    public interface Ability { void cast(ServerLevel level, ServerPlayer player); }

    private final Ability ability;
    private final int baseCooldownTicks;

    public AbilityItem(Item.Properties props, int cooldownSeconds, List<Component> lines, Ability ability) {
        super(props, lines);
        this.ability = ability;
        this.baseCooldownTicks = cooldownSeconds * 20;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && player instanceof ServerPlayer sp && level instanceof ServerLevel sl) {
            ItemStack stack = player.getItemInHand(hand);
            ability.cast(sl, sp);
            int ticks = Math.max(1, Math.round(baseCooldownTicks * (float) ArmorStats.cooldownMult(player)));
            player.getCooldowns().addCooldown(stack, ticks);
        }
        return InteractionResult.SUCCESS;
    }
}
