package com.example.rpgitems;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.item.equipment.Equippable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

public class RpgItems implements ModInitializer {
    public static final String MOD_ID = "rpgitems";

    public static Item TERRESTRIAL, ABSOLUTE_ZERO, BLIGHTSPORE, CATACLYSM;
    public static Item REAPER_HELMET, REAPER_CHESTPLATE, REAPER_LEGGINGS, REAPER_BOOTS;

    /** item -> { skillDamage (fraction), cooldownReduction (fraction) } */
    public static final Map<Item, double[]> ARMOR_STATS = new HashMap<>();

    private static final ResourceKey<EquipmentAsset> REAPER_ASSET =
            ResourceKey.create(EquipmentAssets.ROOT_ID, id("reaper"));

    // ---- tiny delayed-task scheduler ----
    private static final class Task { int left; final Runnable run; Task(int l, Runnable r) { left = l; run = r; } }
    private static final List<Task> TASKS = new ArrayList<>();
    public static void schedule(int ticks, Runnable r) { TASKS.add(new Task(ticks, r)); }

    private static final Map<UUID, Long> LAST_ESSENCE = new HashMap<>();

    private static ResourceLocation id(String s) { return ResourceLocation.fromNamespaceAndPath(MOD_ID, s); }
    private static Component l(String s, ChatFormatting... f) { return Component.literal(s).withStyle(f); }

    private static Item reg(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    private static ItemAttributeModifiers.Builder weaponBase(double damage, double speedMod) {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID,
                        damage - 1, Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(Item.BASE_ATTACK_SPEED_ID,
                        speedMod, Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND);
    }

    private static Item armorPiece(String name, EquipmentSlot slot, EquipmentSlotGroup group, int durability,
                                   double defense, double hp, double skillDmg, double cdr, double speedPct) {
        ItemAttributeModifiers.Builder b = ItemAttributeModifiers.builder()
                .add(Attributes.ARMOR, new AttributeModifier(id(name + "_armor"), defense, Operation.ADD_VALUE), group)
                .add(Attributes.MAX_HEALTH, new AttributeModifier(id(name + "_hp"), hp, Operation.ADD_VALUE), group);
        if (speedPct > 0)
            b.add(Attributes.MOVEMENT_SPEED, new AttributeModifier(id(name + "_spd"), speedPct,
                    Operation.ADD_MULTIPLIED_BASE), group);

        List<Component> lines = new ArrayList<>();
        lines.add(l("Armor", ChatFormatting.RED));
        lines.add(l("Skill Damage: +" + Math.round(skillDmg * 100) + "%", ChatFormatting.GRAY));
        lines.add(l("Defense: +" + (int) defense, ChatFormatting.GRAY));
        lines.add(l("Health: +" + (int) hp, ChatFormatting.RED));
        lines.add(l("Skill Cooldown Reduction: +" + Math.round(cdr * 100) + "%", ChatFormatting.GRAY));
        if (speedPct > 0) lines.add(l("Movement Speed: +" + Math.round(speedPct * 100) + "%", ChatFormatting.GRAY));
        if (slot == EquipmentSlot.CHEST) {
            lines.add(Component.empty());
            lines.add(l("ESSENCE THEFT", ChatFormatting.WHITE, ChatFormatting.BOLD));
            lines.add(l("Slaying an enemy heals 10% max HP (2s cooldown)", ChatFormatting.GRAY));
        }
        lines.add(Component.empty());
        lines.add(l("Tier: LEGENDARY", ChatFormatting.GOLD, ChatFormatting.BOLD));

        Item item = reg(name, p -> new LoreItem(p, lines), new Item.Properties()
                .rarity(Rarity.EPIC)
                .durability(durability)
                .attributes(b.build())
                .component(DataComponents.EQUIPPABLE, Equippable.builder(slot).setAsset(REAPER_ASSET).build()));
        ARMOR_STATS.put(item, new double[]{ skillDmg, cdr });
        return item;
    }

    @Override
    public void onInitialize() {
        // ---------------- Weapons ----------------
        TERRESTRIAL = reg("terrestrial", p -> new AbilityItem(p, 120,
                List.of(l("Attack Damage: 158", ChatFormatting.GRAY), l("Crit Chance: +100%", ChatFormatting.GRAY),
                        l("Parry Rating: +15%", ChatFormatting.GRAY), Component.empty(),
                        l("LEAP OF FAITH (Right Click)", ChatFormatting.WHITE),
                        l("Become immune, leap upwards, then strike the ground:", ChatFormatting.GRAY),
                        l("1000 dmg, crumbled and rooted. Cooldown 120s", ChatFormatting.GRAY),
                        l("MYTHIC", ChatFormatting.LIGHT_PURPLE)),
                Abilities::leapOfFaith),
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).attributes(weaponBase(158, -2.4).build()));

        ABSOLUTE_ZERO = reg("absolute_zero", p -> new AbilityItem(p, 80,
                List.of(l("Attack Damage: 142", ChatFormatting.GRAY), l("Attack Speed: 2/s", ChatFormatting.GRAY),
                        l("Defense: +50", ChatFormatting.GRAY), l("Tenacity: +30%", ChatFormatting.AQUA),
                        Component.empty(),
                        l("FROZEN TOMB (Right Click)", ChatFormatting.WHITE),
                        l("Entomb yourself in dark ice, invulnerable. Then it spreads:", ChatFormatting.GRAY),
                        l("250 damage and stun 3s. Cooldown 80s", ChatFormatting.GRAY),
                        l("MYTHIC", ChatFormatting.LIGHT_PURPLE)),
                Abilities::frozenTomb),
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).attributes(weaponBase(142, -2.0)
                        .add(Attributes.ARMOR, new AttributeModifier(id("az_armor"), 50, Operation.ADD_VALUE),
                                EquipmentSlotGroup.MAINHAND).build()));

        BLIGHTSPORE = reg("blightspore", p -> new AbilityItem(p, 5,
                List.of(l("Staff", ChatFormatting.RED), l("Attack Damage: 70", ChatFormatting.GRAY),
                        l("Skill Crit Chance: +15%", ChatFormatting.GRAY), l("Skill Crit Power: +50%", ChatFormatting.GRAY),
                        l("Defense: +50", ChatFormatting.GRAY), l("Movement Speed: +5%", ChatFormatting.GRAY),
                        Component.empty(),
                        l("BLOODBURST (Right Click)", ChatFormatting.WHITE),
                        l("Consumes 10% max HP to deal 10x max HP as AOE damage. Cooldown 5s", ChatFormatting.GRAY),
                        l("Tier: GODLIKE", ChatFormatting.YELLOW)),
                Abilities::bloodburst),
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).attributes(weaponBase(70, -2.4)
                        .add(Attributes.ARMOR, new AttributeModifier(id("bs_armor"), 50, Operation.ADD_VALUE),
                                EquipmentSlotGroup.MAINHAND)
                        .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(id("bs_speed"), 0.05,
                                Operation.ADD_MULTIPLIED_BASE), EquipmentSlotGroup.MAINHAND).build()));

        CATACLYSM = reg("the_cataclysm", p -> new AbilityItem(p, 85,
                List.of(l("Staff", ChatFormatting.RED), l("Attack Damage: 75", ChatFormatting.GRAY),
                        l("Skill Crit Chance: +100%", ChatFormatting.GRAY), l("Skill Crit Power: +50%", ChatFormatting.GRAY),
                        l("Range: 15", ChatFormatting.GRAY), Component.empty(),
                        l("DOOMSDAY (Right Click)", ChatFormatting.WHITE),
                        l("Root yourself 3s, then unleash a void blast: 650 + 100% max HP. Cooldown 85s",
                                ChatFormatting.GRAY),
                        l("Tier: MYTHIC", ChatFormatting.LIGHT_PURPLE)),
                Abilities::doomsday),
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).attributes(weaponBase(75, -2.4).build()));

        // ---------------- Reaper armor set ----------------
        //                      name                slot                 group                      dur  def  hp  skill cdr  spd
        REAPER_HELMET     = armorPiece("reaper_helmet",     EquipmentSlot.HEAD,  EquipmentSlotGroup.HEAD,  407, 40, 25, 0.15, 0.03, 0);
        REAPER_CHESTPLATE = armorPiece("reaper_chestplate", EquipmentSlot.CHEST, EquipmentSlotGroup.CHEST, 592, 70, 40, 0.25, 0.05, 0);
        REAPER_LEGGINGS   = armorPiece("reaper_leggings",   EquipmentSlot.LEGS,  EquipmentSlotGroup.LEGS,  555, 55, 30, 0.20, 0.04, 0);
        REAPER_BOOTS      = armorPiece("reaper_boots",      EquipmentSlot.FEET,  EquipmentSlotGroup.FEET,  481, 35, 20, 0.10, 0.02, 0.05);

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(e -> {
            e.accept(TERRESTRIAL); e.accept(ABSOLUTE_ZERO); e.accept(BLIGHTSPORE); e.accept(CATACLYSM);
            e.accept(REAPER_HELMET); e.accept(REAPER_CHESTPLATE); e.accept(REAPER_LEGGINGS); e.accept(REAPER_BOOTS);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            List<Runnable> due = new ArrayList<>();
            Iterator<Task> it = TASKS.iterator();
            while (it.hasNext()) { Task t = it.next(); if (--t.left <= 0) { due.add(t.run); it.remove(); } }
            due.forEach(Runnable::run);
        });

        // Essence Theft (chestplate): kill heals 10% max HP, 2s cooldown
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, entity, killed) -> {
            if (entity instanceof ServerPlayer p && p.getItemBySlot(EquipmentSlot.CHEST).is(REAPER_CHESTPLATE)) {
                long now = world.getGameTime();
                Long last = LAST_ESSENCE.get(p.getUUID());
                if (last == null || now - last >= 40) {
                    p.heal(p.getMaxHealth() * 0.10f);
                    LAST_ESSENCE.put(p.getUUID(), now);
                }
            }
        });
    }
}
